###################################################################################################
#
# Copyright 2020 Otmar Nitsche
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
###################################################################################################
#
#   This is the modified exporter for the Blender2MSFS addon.
#   The only purpose of the modification is to allow for extensions
#   in the "asset" section of the glTF file.
#
###################################################################################################

import time

import bpy
import sys
import traceback

from ..com import gltf2_blender_json
from . import gltf2_blender_export_keys
from . import gltf2_blender_gather
#from io_scene_gltf2.blender.exp import gltf2_blender_gather
from .gltf2_blender_gltf2_exporter import GlTF2Exporter #replacing the original exporter here.
from ..com.gltf2_io_debug import print_console, print_newline
from . import gltf2_io_export
from . import gltf2_io_draco_compression_extension
from .gltf2_io_user_extensions import export_user_extensions


def save_ext_gltf(context, export_settings):
    """Start the glTF 2.0 export and saves to content either to a .gltf or .glb file."""
    if bpy.context.active_object is not None:
        if bpy.context.active_object.mode != "OBJECT": # For linked object, you can't force OBJECT mode
            bpy.ops.object.mode_set(mode='OBJECT')

    original_frame = bpy.context.scene.frame_current
    if not export_settings['gltf_current_frame']:
        bpy.context.scene.frame_set(0)

    __notify_start_ext_gltf(context)
    start_time = time.time()
    pre_export_callbacks = export_settings["pre_export_callbacks"]
    for callback in pre_export_callbacks:
        callback(export_settings)

    json, buffer = __export_ext_gltf(export_settings)

    post_export_callbacks = export_settings["post_export_callbacks"]
    for callback in post_export_callbacks:
        callback(export_settings)
    __write_file_ext_gltf(json, buffer, export_settings)

    end_time = time.time()
    __notify_end_ext_gltf(context, end_time - start_time)

    if not export_settings['gltf_current_frame']:
        bpy.context.scene.frame_set(original_frame)

    #save XML file if required:
    if export_settings['gltf_msfs_xml'] == True:
        from .msfs_xml_export import save_xml
        save_xml(context,export_settings)

    return {'FINISHED'}


def __export_ext_gltf(export_settings):
    exporter = GlTF2Exporter(export_settings)
    __gather_ext_gltf(exporter, export_settings)
    buffer = __create_buffer_ext_gltf(exporter, export_settings)
    exporter.finalize_images()
    json = __fix_json_ext_gltf(exporter.glTF.to_dict())

    return json, buffer


def __gather_ext_gltf(exporter, export_settings):
    active_scene_idx, scenes, animations = gltf2_blender_gather.gather_gltf2(export_settings)

    plan = {'active_scene_idx': active_scene_idx, 'scenes': scenes, 'animations': animations}
    export_user_extensions('gather_gltf_hook', export_settings, plan)
    active_scene_idx, scenes, animations = plan['active_scene_idx'], plan['scenes'], plan['animations']

    if export_settings['gltf_draco_mesh_compression']:
        gltf2_io_draco_compression_extension.compress_scene_primitives(scenes, export_settings)
        exporter.add_draco_extension()

    for idx, scene in enumerate(scenes):
        exporter.add_scene(scene, idx==active_scene_idx)
    for animation in animations:
        exporter.add_animation(animation)


def __create_buffer_ext_gltf(exporter, export_settings):
    buffer = bytes()
    if export_settings[gltf2_blender_export_keys.FORMAT] == 'GLB':
        buffer = exporter.finalize_buffer(export_settings[gltf2_blender_export_keys.FILE_DIRECTORY], is_glb=True)
    else:
        if export_settings[gltf2_blender_export_keys.FORMAT] == 'GLTF_EMBEDDED':
            exporter.finalize_buffer(export_settings[gltf2_blender_export_keys.FILE_DIRECTORY])
        else:
            exporter.finalize_buffer(export_settings[gltf2_blender_export_keys.FILE_DIRECTORY],
                                     export_settings[gltf2_blender_export_keys.BINARY_FILENAME])

    return buffer


def __fix_json_ext_gltf(obj):
    # TODO: move to custom JSON encoder
    fixed = obj
    if isinstance(obj, dict):
        fixed = {}
        for key, value in obj.items():
            if not __should_include_json_value_ext_gltf(key, value):
                continue
            fixed[key] = __fix_json_ext_gltf(value)
    elif isinstance(obj, list):
        fixed = []
        for value in obj:
            fixed.append(__fix_json_ext_gltf(value))
    elif isinstance(obj, float):
        # force floats to int, if they are integers (prevent INTEGER_WRITTEN_AS_FLOAT validator warnings)
        if int(obj) == obj:
            return int(obj)
    return fixed


def __should_include_json_value_ext_gltf(key, value):
    allowed_empty_collections = ["KHR_materials_unlit"]

    if value is None:
        return False
    elif __is_empty_collection_ext_gltf(value) and key not in allowed_empty_collections:
        return False
    return True


def __is_empty_collection_ext_gltf(value):
    return (isinstance(value, dict) or isinstance(value, list)) and len(value) == 0


def __write_file_ext_gltf(json, buffer, export_settings):
    try:
        gltf2_io_export.save_gltf(
            json,
            export_settings,
            gltf2_blender_json.BlenderJSONEncoder,
            buffer)
    except AssertionError as e:
        _, _, tb = sys.exc_info()
        traceback.print_tb(tb)  # Fixed format
        tb_info = traceback.extract_tb(tb)
        for tbi in tb_info:
            filename, line, func, text = tbi
            print_console('ERROR', 'An error occurred on line {} in statement {}'.format(line, text))
        print_console('ERROR', str(e))
        raise e


def __notify_start_ext_gltf(context):
    print_console('INFO', 'Starting glTF 2.0 export')
    context.window_manager.progress_begin(0, 100)
    context.window_manager.progress_update(0)


def __notify_end_ext_gltf(context, elapsed):
    print_console('INFO', 'Finished glTF 2.0 export in {} s'.format(elapsed))
    context.window_manager.progress_end()
    print_newline()
